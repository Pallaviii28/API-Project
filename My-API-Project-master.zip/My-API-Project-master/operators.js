//MongoDB Operators -> Powerfull

//Logical Operators

//$inc => increment ,+1,+2,+3, -1 ,-2,-3
//$min => minimum
//$max => maximum
//$set => Used to set a data
//book.title ="xyz"

//$unset => removing a property from an object

//Array operators
//$push
//name = ["aradhana", "xyzzz"]
//$pop
//used to extract/remove/delete the last element
//$pull
//pull: {
//name: "xyzzz"
//}
//$addToSet => doesn't allow duplicates
